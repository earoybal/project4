#!/bin/bash

#trying to isolate each loci to then process individually

#getting line number for each header
pre_header="$(cat -n $1 | grep -E '[[:digit:]]+[[:space:]]{1}[[:digit:]]+[[:space:]]{1}[[:digit:]]+')"
#this will have a set of three columns separated by spaces, first column is linenumber for header, second is seqnum for loci, third is basenum for loci. each row is a loci
#to access pre_header use echo "$pre_header"

#adding extra line to pre_header so that last locus will work in for loop
#pre_header+="$(($(cat $1 | wc -l)+1))" #add one extra line to line count of frogs.txt as it will make it consistent for last loci which would only have one extra line at end otherwise
echo "$pre_header"

#getting number of loci to set limit for for loop
loci_num="$(($(echo "$pre_header" | wc -l)-1))" #gets correct # of loci for frogs.txt

#running for loop to isolate each loci into its own variable
for (( i=1;i<=$loci_num;i++ ))
do
    #getting boundaries for each loci
    start_line="$(echo "$pre_header" | awk -vlocistart=$i 'NR==locistart { print $1 }')" #it works
    end_line="$(echo "$pre_header" | awk -vlociend=$(($i+1)) 'NR==lociend { print $1 }')" #also works

    #loci sequence boundaries
    start_seq="$(($start_line+2))"
    end_seq="$(($end_line-2))"
    
    #isolating sequences for each loci
    loci$i="$(awk -vstartloci=$start_seq -vendloci=$end_seq 'NR>=startloci && NR<=endloci { print $0 }' $1)" #works now
done

#echo "$loci1"


#$header_line | awk -F ' ' '{ print $2 }'
#for chunk in header_line
#do
#    cat $1 | awk 'NR>='${header_line[$i]}' && NR<'${header_line[$n]}' { print $0 }'
#    #bash is zero indexed so notch i and n up by 1 after getting locus
#    i=$(($i+1))
#    n=$(($n+1))
#done
